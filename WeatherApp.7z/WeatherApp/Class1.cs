﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        double f(double x)
        {
            return Math.Sin(x) / x;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Считываем с формы требуемые значения

            double Xmin = double.Parse(xmin.Text);
            if (Xmin < 0)
            {
                MessageBox.Show("Xmin должен быть больше нуля", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            double Xmax = double.Parse(xmax.Text);
            if (Xmin > Xmax)
            {
                MessageBox.Show("Xmin должен быть меньше Xmax", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            double Step = double.Parse(step.Text);
            if (Step > Xmax - Xmin)
            {
                MessageBox.Show("Step > Xmax - Xmin", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Step < 0)
            {
                MessageBox.Show("Step должен быть больше нуля", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Количество точек графика

            int count = (int)Math.Ceiling((Xmax - Xmin) / Step) + 1;



            // Массив значений X

            double[] x = new double[count];



            // Массив Y

            double[] y = new double[count];


            double Integral; // здесь будет интеграл              
            double n = Xmin / Step;
            for (int j = 0; j < count; j++)
            {
                if (j == 0)
                {
                    x[j] = Xmin;
                }
                else
                {
                    x[j] = Xmin + Step * j;
                }


                Integral = 0;
                n = (x[j] - Xmin) / Step;
                for (int i = 1; i <= n; i++)
                {
                    Integral = Integral + Step * f(Xmin + Step * (i - 0.5));
                }

                y[j] = Integral;
            }

            chart1.ChartAreas[0].AxisX.Minimum = Xmin;
            chart1.ChartAreas[0].AxisX.Maximum = Xmax;

            // Определяем шаг сетки

            chart1.ChartAreas[0].AxisX.Interval = Step;

            chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;

            // Добавляем вычисленные значения в графики

            chart1.Series[0].Points.DataBindXY(x, y);

            Microsoft.Office.Interop.Excel.Application ObjExcel = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ObjWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ObjWorkSheet;
            //Книга.
            ObjWorkBook = ObjExcel.Workbooks.Add(System.Reflection.Missing.Value);
            //Таблица.
            ObjWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ObjWorkBook.Sheets[1];

            ObjWorkSheet.Cells[1, 1] = "X";
            ObjWorkSheet.Cells[1, 2] = "Y";


            for (int i = 2, j = 0; i < count + 2 && j < count; i++, j++)
            {
                ObjWorkSheet.Cells[i, 1] = x[j];
                ObjWorkSheet.Cells[i, 2] = y[j];

            }



            //Выделяем данные
            ObjWorkSheet.get_Range("A1:B" + (count + 1));

            //Создаем объект Excel.Chart диаграмму по умолчанию
            Excel.Chart excelchart = (Excel.Chart)ObjExcel.Charts.Add(Type.Missing, Type.Missing, Type.Missing, Type.Missing);


            excelchart.Activate();

            //Изменяем тип диаграммы
            ObjExcel.ActiveChart.ChartType = Excel.XlChartType.xlLineMarkers;


            //Перемещаем диаграмму на лист 1
            ObjExcel.ActiveChart.Location(Excel.XlChartLocation.xlLocationAsObject, "Лист1");
            //Получаем ссылку на лист 1
            var excelsheets = ObjWorkBook.Worksheets;
            ObjWorkSheet = (Excel.Worksheet)excelsheets.get_Item(1);
            //Перемещаем диаграмму в нужное место
            ObjWorkSheet.Shapes.Item(1).IncrementLeft(50);
            ObjWorkSheet.Shapes.Item(1).IncrementTop(50);
            //Задаем размеры диаграммы
            ObjWorkSheet.Shapes.Item(1).Height = 550;
            ObjWorkSheet.Shapes.Item(1).Width = 500;

            ObjExcel.Visible = true;
            ObjExcel.UserControl = true;




            ObjExcel.DisplayAlerts = false;
            ObjWorkBook.SaveAs("E:\\1.xlsx");

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void xmin_TextChanged(object sender, EventArgs e)
        {

        }

        private void xmax_TextChanged(object sender, EventArgs e)
        {

        }

        private void step_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
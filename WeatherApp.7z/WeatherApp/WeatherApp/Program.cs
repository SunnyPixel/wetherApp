﻿using System;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace WeatherApp
{
      class Program
    {
        public static void CreateDiag(string FileName, int li)
        {
            Excel.Application app = new Excel.Application();
            Excel.Workbooks workbooks = null;
            Excel.Workbook workbook = null;
            Microsoft.Office.Interop.Excel.Worksheet excelsh;
            Excel.Sheets sheets = null;
            try
            {
                workbooks = app.Workbooks;
                workbook = workbooks.Open(FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                            Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                            Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                //sheets = workbook.Sheets[li].Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell).Row;
                //sheets = workbook.Sheets.Item[li];
                sheets = workbook.Sheets;
                excelsh = (Microsoft.Office.Interop.Excel.Worksheet)app.Sheets[1];

                Console.WriteLine(" \n Файл {0} лист {1} ячейка {2}", FileName, li.ToString(), sheets[li].ToString());
                foreach (Excel.Worksheet worksheet in sheets)
                {
                    if (worksheet.Index == li)
                    {
                        // Создание диаграммы
                        //Excel.Range UR = worksheet.UsedRange;

                        //Excel.Range head = UR.Cells["A1:C1"];
                        //Excel.Range dia = UR.Cells["A1:A1000"];
                        worksheet.Activate();
                        
                        worksheet.get_Range("A2", "B1000"); 
                        ////    //Создаем объект Excel.Chart диаграмму по умолчанию
                        Excel.Chart excelchart = (Excel.Chart)app.Charts.Add(Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        ////    excelchart.Activate();
                        ////    //Изменяем тип диаграммы
                        app.ActiveChart.ChartType = Excel.XlChartType.xlLineMarkers;
                        app.ActiveChart.Location(Excel.XlChartLocation.xlLocationAsObject, "Лист3");
                        //Получаем ссылку на лист 1


                        var excelsheets = workbook.Worksheets;
                        excelsh = (Excel.Worksheet)excelsheets.get_Item(li);
                        //Перемещаем диаграмму в нужное место
                        excelsh.Shapes.Item(1).IncrementLeft(-201);
                        excelsh.Shapes.Item(1).IncrementTop((float)20.5);
                        //Задаем размеры диаграммы
                        excelsh.Shapes.Item(1).Height = 550;
                        excelsh.Shapes.Item(1).Width = 500;

                        app.Visible = true;
                        app.UserControl = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(" \n Возникло исключение {0}", ex.ToString());
            }
            finally
            {
                /* Очистка оставшихся неуправляемых ресурсов */
                if (sheets != null) Marshal.ReleaseComObject(sheets);
                if (workbook != null)
                {
                    workbook.Close(true);
                    Marshal.ReleaseComObject(workbook);
                    workbook = null;
                }

                if (workbooks != null)
                {
                    workbooks.Close();
                    Marshal.ReleaseComObject(workbooks);
                    workbooks = null;
                }
                if (app != null)
                {
                    app.Quit();
                    Marshal.ReleaseComObject(app);
                    app = null;
                }

                // Console.Read();
            }
        }

        public static void LoadExcelFile(string FileName,int li, Double temp, string par1, string par2, string par3, DateTime dateT)
        {
            object[] arr_q = new object[3];

            arr_q[0] = dateT;
            arr_q[1] = temp;
            arr_q[2] = par1;

            Excel.Application app = new Excel.Application();
            Excel.Workbooks workbooks = null;
            Excel.Workbook workbook = null;

            Excel.Sheets sheets = null;
            try
            {
                workbooks = app.Workbooks;
                workbook = workbooks.Open(FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                            Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                            Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                //sheets = workbook.Sheets[li].Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell).Row;
                //sheets = workbook.Sheets.Item[li];
                sheets = workbook.Sheets;

                //Console.WriteLine(" \n Файл {0} лист {1} ячейка {2}", FileName, li.ToString(), sheets[li].ToString());
                 foreach (Excel.Worksheet worksheet in sheets)
                {
                    if (worksheet.Index == li)
                    {
                        worksheet.Activate();
                        //Console.WriteLine(" \n Лист {0}", worksheet.Name.ToString());
                        Excel.Range UsedRange = worksheet.UsedRange;
                        // Получаем строки в используемом диапазоне
                        Excel.Range urRows = UsedRange.Rows;
                        // Получаем столбцы в используемом диапазоне
                        Excel.Range urColums = UsedRange.Columns;


                        int RowsCount = urRows.Count;
                        int ColumnsCount = urColums.Count;

                        int RowsCount_b;

                        //if (RowsCount == 1)
                        //{
                        //    RowsCount_b = RowsCount;
                        //}
                        //else
                        //{
                        //    RowsCount_b = RowsCount + 1;
                        //}
                        // Заполнение заголовков

                        Excel.Range CR1 = UsedRange.Cells[1,1];
                        CR1.Value2 = "Дата";
                        Excel.Range CR2 = UsedRange.Cells[1,2];
                        CR2.Value2 = "Температура";
                        Excel.Range CR3 = UsedRange.Cells[1,3];
                        CR3.Value2 = "Погода";

                        //Console.WriteLine("\n Количество строк {0}", RowsCount.ToString());
                        RowsCount_b = RowsCount + 1;

                        for (int j = 1; j < 4; j++)
                        {
                            Excel.Range CellRange = UsedRange.Cells[RowsCount_b, j];
                            CellRange.ColumnWidth = 30;
                            CellRange.HorizontalAlignment = 3;
                            if (j == 1)
                            {
                                CellRange.Value = arr_q[j - 1];
                                
                            }
                            else CellRange.Value2 = arr_q[j - 1];
                            //Console.WriteLine("\n проверка значения {0}", arr_q[j - 1].ToString()) ;
                            workbook.Save();
                        }
                    }
                    // Создание диаграммы
                    //Excel.Range UR = worksheet.UsedRange;

                    //Excel.Range head = UR.Cells["A1:B1"];
                    //Excel.Range dia = UR.Cells["A1:A1000"];

                //    worksheet.get_Range("A1", "B1000");

                ////    //Создаем объект Excel.Chart диаграмму по умолчанию
                //   Excel.Chart excelchart = (Excel.Chart)app.Charts.Add(Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                ////    excelchart.Activate();


                ////    //Изменяем тип диаграммы
                //    app.ActiveChart.ChartType = Excel.XlChartType.xlLineMarkers;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(" \n Возникло исключение {0}", ex.ToString());
            }
            finally
            {
                /* Очистка оставшихся неуправляемых ресурсов */
                if (sheets != null) Marshal.ReleaseComObject(sheets);
                if (workbook != null)
                {
                    workbook.Close(true);
                    Marshal.ReleaseComObject(workbook);
                    workbook = null;
                }

                if (workbooks != null)
                {
                    workbooks.Close();
                    Marshal.ReleaseComObject(workbooks);
                    workbooks = null;
                }
                if (app != null)
                {
                    app.Quit();
                    Marshal.ReleaseComObject(app);
                    app = null;
                }

                // Console.Read();
            }


        }
        public static void createExcelFile()
        {
            Excel.Application app = new Excel.Application
            {
                //Отобразить Excel
                Visible = false,
                //Количество листов в рабочей книге
                SheetsInNewWorkbook = 2
            };
            //Добавить рабочую книгу
            Excel.Workbook workBook = app.Workbooks.Add(Type.Missing);
            //Отключить отображение окон с сообщениями
            app.DisplayAlerts = false;
            //Получаем первый лист документа (счет начинается с 1)
            Excel.Worksheet sheet = (Excel.Worksheet)app.Worksheets.get_Item(1);
            //Название листа (вкладки снизу)
            sheet.Name = "ПогодаНижнийНовгород";

            Excel.Worksheet sheet1 = (Excel.Worksheet)app.Worksheets.get_Item(2);
            //Название листа (вкладки снизу)
            sheet1.Name = "ПогодаМосква";


            app.Application.ActiveWorkbook.SaveAs("C:\\Temp\\прогнозПогоды.xlsx", Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

           
            //Console.WriteLine("\n Файл создан {0}", app.ActiveWorkbook.Name.ToString());
            
            app.Quit();
            System.Runtime.InteropServices.Marshal.ReleaseComObject(app);
        }

        public static async Task ConnectAsync(int CountryID, int lis)
        {
            // запрос с API 
            int i;
            //WebRequest request = WebRequest.Create("https://api.openweathermap.org/data/2.5/weather?id=" + CountryID + "&units=metric&dt=1676612995&APPID=840096a6dbbf6f8623b96a4907873b7a&&lang=ru");
            WebRequest request = WebRequest.Create("https://api.openweathermap.org/data/2.5/forecast?id=" + CountryID + "&exclude=hourly,daily&units=metric&dt=1676612995&APPID=840096a6dbbf6f8623b96a4907873b7a&&lang=ru");
            request.Method = "POST";
            WebResponse response = await request.GetResponseAsync();
            string answer = string.Empty;
            using (Stream s = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(s))
                {
                    answer = await reader.ReadToEndAsync();
                }

            }
            response.Close();
            WeatherResponse response_global = JsonConvert.DeserializeObject<WeatherResponse>(answer);
            string path = @"C:\Temp\прогнозПогоды.xlsx";

            bool fileExist = File.Exists(path);
            if (fileExist)
            {
                //Console.WriteLine("Файл существует");
            }
            else
            {
                //Console.WriteLine("Файл существует");
                createExcelFile();
            }

            for (i = 0; i < 40; i++)
            {
                DateTime dateN = new DateTime(1970, 1, 1).AddSeconds(response_global.list[i].dt);
                if (dateN.ToShortTimeString().ToString() == "12:00")
                {
                    //dateN = DateTime.Parse(dateN.ToLongDateString().ToString());
                    LoadExcelFile(@"C:\Temp\прогнозПогоды.xlsx", lis, response_global.list[i].main.temp, response_global.list[i].weather[0].description, null, null, DateTime.Parse(dateN.ToShortDateString()));
                }
                //Console.WriteLine("Средняя температура в данный момент {0} в городе " + response_global.list[i].name + " = " + response_global.list[i].main.temp, dateN);
                //Console.WriteLine("Погода за окном: \n" + response_global.list[i].weather[0].main + "\n" + response_global.list[i].weather[0].description);
//            DateTime dt1 = new DateTime(1970, 1, 1).AddSeconds(response_global.list[1].dt);
//Console.WriteLine("Средняя температура в данный момент {0} в городе " + response_global.list[1].name + " = " + response_global.list[1].main.temp, dt.ToString());
//Console.WriteLine("Погода за окном: \n" + response_global.list[1].weather[0].main + "\n" + response_global.list[1].weather[0].description);
//            DateTime dt2 = new DateTime(1970, 1, 1).AddSeconds(response_global.list[2].dt);
//Console.WriteLine("Средняя температура в данный момент {0} в городе " + response_global.list[0].name + " = " + response_global.list[2].main.temp, dt.ToString());
//Console.WriteLine("Погода за окном: \n" + response_global.list[2].weather[0].main + "\n" + response_global.list[2].weather[0].description);
//            DateTime dt3 = new DateTime(1970, 1, 1).AddSeconds(response_global.list[3].dt);
//Console.WriteLine("Средняя температура в данный момент {0} в городе " + response_global.list[0].name + " = " + response_global.list[3].main.temp, dt.ToString());
//Console.WriteLine("Погода за окном: \n" + response_global.list[3].weather[0].main + "\n" + response_global.list[3].weather[0].description);
//            DateTime dt4 = new DateTime(1970, 1, 1).AddSeconds(response_global.list[4].dt);
//Console.WriteLine("Средняя температура в данный момент {0} в городе " + response_global.list[0].name + " = " + response_global.list[4].main.temp, dt.ToString());
//Console.WriteLine("Погода за окном: \n" + response_global.list[4].weather[0].main + "\n" + response_global.list[4].weather[0].description);
            }
      }

        static void UpdateFileExcel()
        {
            // - передача данных в файл Excel 

        }

        static void Main(string[] args)
        {

            try
            {
                // - Загрузка по Нижнему Новгороду 
                ConnectAsync(520555, 1).Wait();
                Console.WriteLine("Нижний Новгород успешно");
                // - Загрузка по Москве 
                ConnectAsync(524901, 2).Wait();
                Console.WriteLine("Москва успешно");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.Write("Город не найден или что-то пошло не так");
            }
            finally
            {

            }

            Console.ReadKey();
        }
    }
}

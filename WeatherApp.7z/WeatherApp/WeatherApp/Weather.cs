﻿using System;

public class Temperatura
{
    public double temp;
}

public class WeatherNow
{
    public string main;
    public string description;
}

public class WeatherNowList
{
    public string description;
    public Double dt;
    public Temperatura main;
    public string name;
    public WeatherNow[] weather;

}

public class WeatherResponse
{
    public WeatherNowList[] list;
}
public class Weather
{
    public Weather()
	{

	}
}
